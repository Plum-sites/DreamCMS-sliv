/**
 * App Config File
 */
export default {
	appLogo: '/images/logo.png',                                   // App Logo,
	darkLogo: '/images/logo.png',							    // dark logo
	appLogo2: '/images/logo.png',                                    // App Logo 2 For Login & Signup Page
	brand: 'DreamCMS',                                        			        // Brand Name
	copyrightText: 'Beshelmek © 2019 All Rights Reserved.',                     // Copyright Text
	enableUserTour: false,   // Enable User Tour
	weatherApiId: 'b1b15e88fa797225412429c1c50c122a1',						// weather API Id
	weatherApiKey: '69b72ed255ce5efad910bd946685883a'						// weather APi key
}
