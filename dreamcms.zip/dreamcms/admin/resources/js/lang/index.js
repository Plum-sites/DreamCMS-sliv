import en from './en';
import ru from './ru';

export default {
    en: {
        message: en
    },
    ru: {
        message: ru
    }
}