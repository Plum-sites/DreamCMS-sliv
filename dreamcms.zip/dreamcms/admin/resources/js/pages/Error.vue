<template>
    <v-container pt-70 px-0>
        <v-layout row wrap>
            <v-flex xs12 sm8 md4 mx-auto>
                <div class="lock-screen-block text-xs-center">
                    <h2>Ошибка</h2>
                    <h3>Недостаточно прав!</h3>
                </div>
            </v-flex>
        </v-layout>
    </v-container>
</template>

<script>
    export default {
        name: "Error"
    }
</script>