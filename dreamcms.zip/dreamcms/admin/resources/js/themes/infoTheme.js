export default {
   primary: '#00D0BD',
   secondary: '#424242',
   accent: '#82B1FF',
   error: '#FF3739',
   info: '#5D92F4',
   success: '#00D014',
   warning: '#FFB70F'
}