<template>
   <div class="banner-image-wrap courses-bg-img">
      <div class="banner-content-wrap fill-height bg-warn-overlay">
         <v-layout align-center justify-center row fill-height>
            <v-flex xs9 sm9 md10 lg10 xl10>
               <h2 class="white--text">Learn With Your Convenience</h2>
               <h4 class="white--text">Learn any Course anywhere anytime from our 200 courses starting from $60 USD.</h4>
               <v-layout row wrap ma-0>
                  <v-flex xs10 sm6 md3 lg2 xl3 pa-0>
                     <div class="search">
                        <v-form class="search-form">
                           <v-text-field
                              dark
                              color="white"
                              placeholder="Find Your Course"
                           ></v-text-field>
                        </v-form>                             
                     </div>
                  </v-flex>
               </v-layout>
            </v-flex>
         </v-layout>
      </div>
   </div>
</template>
