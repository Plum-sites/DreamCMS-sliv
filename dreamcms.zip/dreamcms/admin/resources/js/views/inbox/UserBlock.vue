<template>
   <v-img class="white--text" height="150px" src="/static/img/blog-1.jpg">
      <div class="media align-items-center pa-3 w-100">
         <div class="media-left mr-4">
            <img src="/static/avatars/user-9.jpg" class="rounded-circle img-responsive" width="70" height="70">
         </div>
         <div class="media-body">
            <h5 class="mb-0">Gregory A.</h5>
            <span class="fs-12 fw-normal">gregory@example.com</span>
         </div>
      </div>
   </v-img>
</template>
