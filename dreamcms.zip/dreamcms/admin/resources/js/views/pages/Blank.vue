<template>
	<page-title-bar></page-title-bar>
</template>
